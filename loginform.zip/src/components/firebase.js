
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getAuth} from "firebase/auth";
import {getFirestore} from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
 apiKey: "AIzaSyDD9yNiH-V6Yn9X_c3zhkcRRhRvR7vKd8I",
    authDomain: "loginform-4b3fa.firebaseapp.com",
    projectId: "loginform-4b3fa",
    storageBucket: "loginform-4b3fa.appspot.com",
    messagingSenderId: "1065304011541",
    appId: "1:1065304011541:web:f1a587480e4b3090526f1c",
    measurementId: "G-PGHBC2SH6N"
  };
// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const auth=getAuth();
export const db=getFirestore(app);
export default app;